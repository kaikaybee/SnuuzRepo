package com.example.alarmnotif;

import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class AlarmNotif extends AppCompatActivity {

    //Button wakeUp = findViewById(R.id.wake_up_timeDialog);

    @Override
    public void onCreate(Bundle savedInstanceState) {
        //new activity opened at the time the alarm was set. Bypasses screen locks.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm_notif);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
        r.play();
        //commented out code below crashes
        /*final MediaPlayer player = MediaPlayer.create(this, notification);
        player.setLooping(true);
        player.start();
        wakeUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player.stop();
            }
        });*/
    }
}