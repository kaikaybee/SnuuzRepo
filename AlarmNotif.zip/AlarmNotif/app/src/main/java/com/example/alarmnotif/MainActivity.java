package com.example.alarmnotif;

import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import androidx.appcompat.widget.Toolbar;
import android.os.Bundle;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import android.widget.Toast;

import android.content.Intent;
import android.app.AlarmManager;
import android.app.PendingIntent;

public class MainActivity extends AppCompatActivity {

    Button buttonStartSetDialog;
    Button buttonCancelAlarm;
    TextView textAlarmPrompt;
    AlarmManager alarm;
    PendingIntent alarmIntent;
    TimePickerDialog timePickerDialog;
    String date;
    String wake_up;
    String sleep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
        //dialog for setting alarm
        textAlarmPrompt = findViewById(R.id.alarm_prompt);
        buttonStartSetDialog = findViewById(R.id.startSetDialog);
        buttonStartSetDialog.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                textAlarmPrompt.setText("");
                openTimePickerDialog(false);

            }
        });
        buttonCancelAlarm = findViewById(R.id.cancel);
        buttonCancelAlarm.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //cancelAlarm();
                alarm.cancel(alarmIntent);
            }
        });
    }

    private void openTimePickerDialog(boolean is24r){
        Calendar calendar = Calendar.getInstance();

        timePickerDialog = new TimePickerDialog(
                MainActivity.this,
                onTimeSetListener,
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                is24r);
        timePickerDialog.setTitle("Set Alarm Time");

        timePickerDialog.show();


    }

    //Brian's code - please comment
    //Takes inputted User alarm time and sets alarm
    OnTimeSetListener onTimeSetListener
            = new OnTimeSetListener(){

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

            Calendar calNow = Calendar.getInstance();
            Calendar calSet = (Calendar) calNow.clone();

            calSet.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calSet.set(Calendar.MINUTE, minute);
            calSet.set(Calendar.SECOND, 0);
            calSet.set(Calendar.MILLISECOND, 0);

//            if(calSet.compareTo(calNow) <= 0){
//                //Today Set time passed, count to tomorrow
//                calSet.add(Calendar.DATE, 1);
//            }

            //Sets variables from time picker
            SimpleDateFormat time_format = new SimpleDateFormat("HH:mm");
            SimpleDateFormat date_format = new SimpleDateFormat("MM-dd-yyyy");
            date = date_format.format((new Date()));
            wake_up = calSet.get(calSet.HOUR_OF_DAY) + ":" + calSet.get(calSet.MINUTE);
            sleep = time_format.format(calSet.getInstance().getTime());

            setAlarm(calSet);
        }};
    private void setAlarm(Calendar targetCal) {
        //sets alarm by sending alarm data to a receiver with a pending intent.
        //records time when the alarm was set by the user(not the time the alarm will go off)

        textAlarmPrompt.setText(targetCal.getTime().toString());
        Intent AlarmIntent = new Intent(MainActivity.this, AlarmReceiver.class);
        alarmIntent = PendingIntent.getBroadcast(MainActivity.this, 0, AlarmIntent, 0);
        alarm.setExact(AlarmManager.RTC_WAKEUP, targetCal.getTimeInMillis(), alarmIntent);
        try {

            FileOutputStream fileout = openFileOutput("SleepData.txt", MODE_APPEND);
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);

            outputWriter.write("SleepTime: "+Calendar.getInstance().getTime().toString()+"\n");


            outputWriter.close();

            //display file saved message for testing
            Toast.makeText(getBaseContext(), "Sleep time saved successfully!",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
